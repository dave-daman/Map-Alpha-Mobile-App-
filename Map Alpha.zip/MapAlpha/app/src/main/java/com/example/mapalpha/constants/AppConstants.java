package com.example.mapalpha.constants;

/**
 * Application-wide constants for intervals, channels, URLs, and identifiers.
 */
public final class AppConstants {

    private AppConstants() {
    }

    /** Default geofence radius in meters when not specified. */
    public static final float GEOFENCE_RADIUS_DEFAULT = 200f;

    /** Interval between fused location updates in milliseconds. */
    public static final long LOCATION_UPDATE_INTERVAL = 5000L;

    /** Fastest allowed location update interval in milliseconds. */
    public static final long LOCATION_FASTEST_INTERVAL = 2000L;

    /** Geofence dwell time before DWELL transition in milliseconds. */
    public static final int GEOFENCE_LOITERING_DELAY_MS = 30000;

    /** Base URL for Google Directions API (path appended by Retrofit). */
    public static final String DIRECTIONS_BASE_URL = "https://maps.googleapis.com/";

    /** Notification channel ID for foreground location tracking. */
    public static final String CHANNEL_TRACKING = "tracking_channel";

    /** Notification channel ID for geofence alerts. */
    public static final String CHANNEL_GEOFENCE = "geofence_channel";

    /** Human-readable name for the tracking notification channel. */
    public static final String CHANNEL_TRACKING_NAME = "Location Tracking";

    /** Human-readable name for the geofence notification channel. */
    public static final String CHANNEL_GEOFENCE_NAME = "Geo-fence Alerts";

    /** Foreground service notification ID. */
    public static final int NOTIFICATION_ID_TRACKING = 1001;

    /** Base notification ID for geofence alerts (incremented per alert). */
    public static final int NOTIFICATION_ID_GEOFENCE_BASE = 2000;

    /** PendingIntent request code for geofence transitions. */
    public static final int GEOFENCE_PENDING_INTENT_REQUEST_CODE = 9411;

    /**
     * Returns a stable string geofence ID for a saved location row.
     *
     * @param savedLocationId database primary key
     * @return non-null geofence identifier
     */
    public static String geofenceIdForLocation(int savedLocationId) {
        return String.valueOf(savedLocationId);
    }
}
