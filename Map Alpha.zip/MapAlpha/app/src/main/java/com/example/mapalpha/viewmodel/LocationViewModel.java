package com.example.mapalpha.viewmodel;

import android.app.Application;
import android.location.Location;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.mapalpha.MapAlphaApplication;
import com.example.mapalpha.database.SavedLocation;
import com.example.mapalpha.repository.LocationRepository;

import java.util.List;

/**
 * ViewModel for saved locations and the current fused location.
 */
public class LocationViewModel extends AndroidViewModel {

    private final LocationRepository repository;
    private final MutableLiveData<SavedLocation> navigateRequest;
    private final MutableLiveData<Boolean> insertInProgress;

    /**
     * @param application application context
     */
    public LocationViewModel(@NonNull Application application) {
        super(application);
        this.repository = ((MapAlphaApplication) application).getLocationRepository();
        this.navigateRequest = new MutableLiveData<>();
        this.insertInProgress = new MutableLiveData<>(false);
    }

    /**
     * @return latest fused location from the tracking service
     */
    @NonNull
    public LiveData<Location> getCurrentLocation() {
        return repository.getCurrentLocation();
    }

    /**
     * @return all saved locations
     */
    @NonNull
    public LiveData<List<SavedLocation>> getSavedLocations() {
        return repository.getAllLocations();
    }

    /**
     * @return true while a database insert is running
     */
    @NonNull
    public LiveData<Boolean> getInsertInProgress() {
        return insertInProgress;
    }

    /**
     * Requests navigation on the map to the given saved location (consumed by {@link com.example.mapalpha.ui.MapFragment}).
     *
     * @param location target
     */
    public void requestNavigateTo(@Nullable SavedLocation location) {
        navigateRequest.setValue(location);
    }

    /**
     * @return one-shot navigation requests for the map tab
     */
    @NonNull
    public LiveData<SavedLocation> getNavigateRequest() {
        return navigateRequest;
    }

    /**
     * Clears the navigation request after handling.
     */
    public void clearNavigateRequest() {
        navigateRequest.setValue(null);
    }

    /**
     * Inserts a location asynchronously.
     *
     * @param location entity with {@code id = 0}
     * @param callback invoked on main thread with inserted row
     */
    public void insertLocation(@NonNull SavedLocation location, @NonNull LocationRepository.InsertCallback callback) {
        insertInProgress.setValue(true);
        repository.insertLocation(location, inserted -> {
            insertInProgress.setValue(false);
            callback.onInserted(inserted);
        });
    }

    /**
     * Deletes a location asynchronously.
     *
     * @param location row to remove
     */
    public void deleteLocation(@NonNull SavedLocation location) {
        repository.deleteLocation(location);
    }

    /**
     * @return underlying repository for background geofence sync
     */
    @NonNull
    public LocationRepository getRepository() {
        return repository;
    }
}
