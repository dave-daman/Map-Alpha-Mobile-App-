package com.example.mapalpha.network;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Retrofit API for Google Directions (JSON over HTTPS).
 */
public interface DirectionsApi {

    /**
     * Requests driving directions between two coordinates.
     *
     * @param origin      "lat,lng"
     * @param destination "lat,lng"
     * @param mode        travel mode, e.g. driving
     * @param key         Maps API key
     * @return call wrapping {@link DirectionsResponse}
     */
    @GET("maps/api/directions/json")
    Call<DirectionsResponse> getDirections(
            @Query("origin") String origin,
            @Query("destination") String destination,
            @Query("mode") String mode,
            @Query("key") String key);
}
