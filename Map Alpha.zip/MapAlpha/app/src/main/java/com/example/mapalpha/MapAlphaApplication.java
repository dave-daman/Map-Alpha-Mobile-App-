package com.example.mapalpha;

import android.app.Application;

import androidx.annotation.NonNull;

import com.example.mapalpha.database.AppDatabase;
import com.example.mapalpha.geofence.GeofenceManager;
import com.example.mapalpha.notifications.NotificationHelper;
import com.example.mapalpha.repository.LocationRepository;

/**
 * Application singleton providing shared {@link LocationRepository} and {@link GeofenceManager}.
 */
public class MapAlphaApplication extends Application {

    private LocationRepository locationRepository;
    private GeofenceManager geofenceManager;

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationHelper.init(this);
        AppDatabase db = AppDatabase.getInstance(this);
        locationRepository = new LocationRepository(db);
        geofenceManager = new GeofenceManager(this);
    }

    /**
     * @return shared location repository
     */
    @NonNull
    public LocationRepository getLocationRepository() {
        return locationRepository;
    }

    /**
     * @return geofence manager bound to this application context
     */
    @NonNull
    public GeofenceManager getGeofenceManager() {
        return geofenceManager;
    }
}
