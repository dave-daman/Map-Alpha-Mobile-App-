package com.example.mapalpha.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.mapalpha.MapAlphaApplication;
import com.example.mapalpha.R;
import com.example.mapalpha.database.SavedLocation;
import com.example.mapalpha.location.LocationTrackingService;
import com.example.mapalpha.viewmodel.LocationViewModel;
import com.example.mapalpha.viewmodel.LocationViewModelFactory;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Host activity: bottom navigation, permissions, Play Services, tracking service, and geofence sync.
 */
public class MainActivity extends AppCompatActivity {

    private LocationViewModel viewModel;
    private BottomNavigationView bottomNav;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private boolean geofenceSynced;

    private final ActivityResultLauncher<String[]> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), this::onPermissionsResult);

    private final ActivityResultLauncher<String> backgroundPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                startTrackingServiceIfPossible();
                syncGeofencesOnceIfPossible();
            });

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewModel = new ViewModelProvider(this, new LocationViewModelFactory(getApplication()))
                .get(LocationViewModel.class);

        bottomNav = findViewById(R.id.bottom_nav);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_map) {
                showFragment(new MapFragment());
                return true;
            }
            if (id == R.id.nav_locations) {
                showFragment(new LocationListFragment());
                return true;
            }
            if (id == R.id.nav_add) {
                showFragment(new AddLocationFragment());
                return true;
            }
            return false;
        });

        if (savedInstanceState == null) {
            bottomNav.setSelectedItemId(R.id.nav_map);
        }

        checkPlayServices();
        requestInitialPermissions();
    }

    /**
     * Switches to the map tab and requests a route to the given location.
     *
     * @param location destination
     */
    public void openMapAndNavigate(@NonNull SavedLocation location) {
        if (bottomNav.getSelectedItemId() != R.id.nav_map) {
            bottomNav.setSelectedItemId(R.id.nav_map);
        } else {
            showFragment(new MapFragment());
        }
        mainHandler.post(() -> viewModel.requestNavigateTo(location));
    }

    /**
     * Opens Google Maps (or a web fallback) for turn-by-turn directions to a saved location.
     *
     * @param location destination
     */
    public void openGoogleMapsDirections(@NonNull SavedLocation location) {
        double lat = location.getLatitude();
        double lng = location.getLongitude();
        Uri uri = Uri.parse("google.navigation:q=" + lat + "," + lng);
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        if (intent.resolveActivity(getPackageManager()) == null) {
            uri = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" + lat + "," + lng);
            intent = new Intent(Intent.ACTION_VIEW, uri);
        }
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, R.string.maps_not_available, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Selects the Locations tab (after saving a new location).
     */
    public void selectLocationsTab() {
        if (bottomNav.getSelectedItemId() != R.id.nav_locations) {
            bottomNav.setSelectedItemId(R.id.nav_locations);
        } else {
            showFragment(new LocationListFragment());
        }
    }

    private void showFragment(@NonNull Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.nav_host_fragment, fragment)
                .commit();
    }

    private boolean checkPlayServices() {
        GoogleApiAvailability api = GoogleApiAvailability.getInstance();
        int status = api.isGooglePlayServicesAvailable(this);
        if (status == ConnectionResult.SUCCESS) {
            return true;
        }
        if (api.isUserResolvableError(status)) {
            android.app.Dialog dialog = api.getErrorDialog(this, status, 9000);
            if (dialog != null) {
                dialog.show();
            }
        } else {
            Toast.makeText(this, R.string.play_services_error, Toast.LENGTH_LONG).show();
        }
        return false;
    }

    private void requestInitialPermissions() {
        List<String> perms = new ArrayList<>();
        perms.add(Manifest.permission.ACCESS_FINE_LOCATION);
        perms.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        permissionLauncher.launch(perms.toArray(new String[0]));
    }

    private void onPermissionsResult(@NonNull Map<String, Boolean> result) {
        boolean fine = Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_FINE_LOCATION));
        if (!fine) {
            showRationaleOrSettings();
            return;
        }
        startTrackingServiceIfPossible();
        syncGeofencesOnceIfPossible();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            boolean background = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                    == PackageManager.PERMISSION_GRANTED;
            if (!background) {
                if (shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_BACKGROUND_LOCATION)) {
                    new AlertDialog.Builder(this)
                            .setMessage(R.string.permission_rationale)
                            .setPositiveButton(android.R.string.ok, (d, w) ->
                                    backgroundPermissionLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
                            .setNegativeButton(android.R.string.cancel, null)
                            .show();
                } else {
                    backgroundPermissionLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION);
                }
            }
        }
    }

    private void showRationaleOrSettings() {
        if (shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
            new AlertDialog.Builder(this)
                    .setMessage(R.string.permission_rationale)
                    .setPositiveButton(R.string.settings, (d, w) -> openAppSettings())
                    .setNegativeButton(android.R.string.cancel, null)
                    .show();
        } else {
            Toast.makeText(this, R.string.permission_rationale, Toast.LENGTH_LONG).show();
        }
    }

    private void openAppSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivity(intent);
    }

    private void startTrackingServiceIfPossible() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        Intent intent = new Intent(this, LocationTrackingService.class);
        ContextCompat.startForegroundService(this, intent);
    }

    private void syncGeofencesOnceIfPossible() {
        if (geofenceSynced) {
            return;
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        geofenceSynced = true;
        viewModel.getSavedLocations().observe(this, new Observer<List<SavedLocation>>() {
            @Override
            public void onChanged(List<SavedLocation> savedLocations) {
                viewModel.getSavedLocations().removeObserver(this);
                List<SavedLocation> list = savedLocations == null ? new ArrayList<>() : savedLocations;
                ((MapAlphaApplication) getApplication()).getGeofenceManager().syncGeofences(list, null);
            }
        });
    }
}
