package com.example.mapalpha.ui;

import android.Manifest;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.mapalpha.BuildConfig;
import com.example.mapalpha.MapAlphaApplication;
import com.example.mapalpha.R;
import com.example.mapalpha.constants.AppConstants;
import com.example.mapalpha.database.SavedLocation;
import com.example.mapalpha.geofence.GeofenceManager;
import com.example.mapalpha.network.DirectionsClient;
import com.example.mapalpha.network.DirectionsResponse;
import com.example.mapalpha.network.RouteJson;
import com.example.mapalpha.viewmodel.LocationViewModel;
import com.example.mapalpha.viewmodel.LocationViewModelFactory;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.maps.android.PolyUtil;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Map tab: user location, saved markers, directions polyline, and center FAB.
 */
public class MapFragment extends Fragment implements OnMapReadyCallback {

    private static final String TAG = "MapFragment";

    private GoogleMap googleMap;
    private LocationViewModel viewModel;
    private GeofenceManager geofenceManager;
    private Polyline routePolyline;
    private final List<Marker> markers = new ArrayList<>();
    private final List<Circle> geofenceCircles = new ArrayList<>();

    /** Temporary marker for long-press save flow (removed after save or cancel). */
    @Nullable
    private Marker pendingDropPinMarker;

    /** Preview geofence circle while the save-pin dialog is open. */
    @Nullable
    private Circle previewGeofenceCircle;

    // Cached navigation request in case it's triggered before the map finishes initializing.
    @Nullable
    private SavedLocation pendingNavigateLocation;

    /**
     * Creates the map fragment.
     */
    public MapFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_map, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(
                requireActivity(),
                new LocationViewModelFactory(requireActivity().getApplication()))
                .get(LocationViewModel.class);
        geofenceManager = ((MapAlphaApplication) requireActivity().getApplication()).getGeofenceManager();

        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager()
                .findFragmentById(R.id.map_container);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        view.findViewById(R.id.fab_center).setOnClickListener(v -> centerOnUser());

        viewModel.getSavedLocations().observe(getViewLifecycleOwner(), this::refreshMarkers);
        viewModel.getNavigateRequest().observe(getViewLifecycleOwner(), this::onNavigateRequest);
        viewModel.getCurrentLocation().observe(getViewLifecycleOwner(), loc -> {
            if (loc == null) {
                return;
            }
            if (googleMap == null || pendingNavigateLocation == null) {
                return;
            }
            SavedLocation target = pendingNavigateLocation;
            pendingNavigateLocation = null;
            drawDirectionsRouteTo(target);
        });
    }

    private void onNavigateRequest(@Nullable SavedLocation location) {
        if (location == null) {
            return;
        }

        // If the map isn't ready yet, defer drawing until `onMapReady()`.
        if (googleMap == null) {
            pendingNavigateLocation = location;
            viewModel.clearNavigateRequest();
            return;
        }

        // If current location isn't available yet, keep the pending destination and draw
        // as soon as `getCurrentLocation()` emits a value.
        if (viewModel.getCurrentLocation().getValue() == null) {
            pendingNavigateLocation = location;
            viewModel.clearNavigateRequest();
            return;
        }

        pendingNavigateLocation = null;
        drawDirectionsRouteTo(location);
        viewModel.clearNavigateRequest();
    }

    @Override
    public void onMapReady(@NonNull GoogleMap map) {
        googleMap = map;
        googleMap.getUiSettings().setZoomControlsEnabled(true);
        if (hasLocationPermission()) {
            try {
                googleMap.setMyLocationEnabled(true);
            } catch (SecurityException ignored) {
                // Permission checked above
            }
        }
        googleMap.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter() {
            @Nullable
            @Override
            public View getInfoWindow(@NonNull Marker marker) {
                return null;
            }

            @Nullable
            @Override
            public View getInfoContents(@NonNull Marker marker) {
                View v = LayoutInflater.from(requireContext()).inflate(R.layout.map_info_window, null);
                TextView title = v.findViewById(R.id.info_title);
                title.setText(marker.getTitle());
                return v;
            }
        });
        googleMap.setOnInfoWindowClickListener(marker -> {
            Object tag = marker.getTag();
            if (tag instanceof SavedLocation) {
                drawDirectionsRouteTo((SavedLocation) tag);
            }
        });

        googleMap.setOnMapLongClickListener(this::onMapLongClick);

        // Handle any navigation request that arrived before the map initialized.
        if (pendingNavigateLocation != null && viewModel.getCurrentLocation().getValue() != null) {
            SavedLocation target = pendingNavigateLocation;
            pendingNavigateLocation = null;
            drawDirectionsRouteTo(target);
        }
    }

    private void onMapLongClick(@NonNull LatLng latLng) {
        if (googleMap == null) {
            return;
        }
        showSavePinDialog(latLng);
    }

    private void showSavePinDialog(@NonNull LatLng latLng) {
        if (pendingDropPinMarker != null) {
            pendingDropPinMarker.remove();
            pendingDropPinMarker = null;
        }
        removePreviewCircle();
        pendingDropPinMarker = googleMap.addMarker(new MarkerOptions()
                .position(latLng)
                .title(getString(R.string.location_name)));

        View form = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_save_pin_location, null);
        TextInputLayout inputName = form.findViewById(R.id.input_pin_name);
        TextInputLayout inputRadius = form.findViewById(R.id.input_pin_radius);
        TextInputEditText editName = form.findViewById(R.id.edit_pin_name);
        TextInputEditText editRadius = form.findViewById(R.id.edit_pin_radius);
        editRadius.setText(String.valueOf((int) AppConstants.GEOFENCE_RADIUS_DEFAULT));

        TextWatcher radiusWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (googleMap == null) {
                    return;
                }
                String str = s != null ? s.toString().trim() : "";
                float radiusMeters;
                if (TextUtils.isEmpty(str)) {
                    radiusMeters = AppConstants.GEOFENCE_RADIUS_DEFAULT;
                } else {
                    try {
                        radiusMeters = Float.parseFloat(str);
                    } catch (NumberFormatException e) {
                        return;
                    }
                }
                if (radiusMeters > 0) {
                    updatePreviewGeofenceCircle(latLng, radiusMeters);
                }
            }
        };
        editRadius.addTextChangedListener(radiusWatcher);
        updatePreviewGeofenceCircle(latLng, AppConstants.GEOFENCE_RADIUS_DEFAULT);

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(requireContext());
        builder.setTitle(R.string.save_pin_title);
        builder.setMessage(getString(R.string.save_pin_coords, latLng.latitude, latLng.longitude));
        builder.setView(form);
        builder.setPositiveButton(R.string.save, null);
        builder.setNegativeButton(android.R.string.cancel, (d, which) -> {
            removePreviewCircle();
            if (pendingDropPinMarker != null) {
                pendingDropPinMarker.remove();
                pendingDropPinMarker = null;
            }
        });

        AlertDialog dialog = builder.create();
        dialog.setOnDismissListener(d -> {
            editRadius.removeTextChangedListener(radiusWatcher);
            removePreviewCircle();
            if (pendingDropPinMarker != null) {
                pendingDropPinMarker.remove();
                pendingDropPinMarker = null;
            }
        });
        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                inputName.setError(null);
                inputRadius.setError(null);
                String name = editName.getText() != null ? editName.getText().toString().trim() : "";
                String radStr = editRadius.getText() != null ? editRadius.getText().toString().trim() : "";
                if (TextUtils.isEmpty(name)) {
                    inputName.setError(getString(R.string.invalid_input));
                    return;
                }
                float radius;
                if (TextUtils.isEmpty(radStr)) {
                    radius = AppConstants.GEOFENCE_RADIUS_DEFAULT;
                } else {
                    try {
                        radius = Float.parseFloat(radStr);
                    } catch (NumberFormatException e) {
                        inputRadius.setError(getString(R.string.invalid_input));
                        return;
                    }
                }
                if (radius <= 0) {
                    inputRadius.setError(getString(R.string.invalid_input));
                    return;
                }

                removePreviewCircle();
                SavedLocation entity = new SavedLocation(
                        0,
                        name,
                        latLng.latitude,
                        latLng.longitude,
                        radius,
                        System.currentTimeMillis());

                if (pendingDropPinMarker != null) {
                    pendingDropPinMarker.remove();
                    pendingDropPinMarker = null;
                }
                dialog.dismiss();

                viewModel.insertLocation(entity, inserted ->
                        geofenceManager.addGeofence(inserted).addOnCompleteListener(task -> {
                            if (!task.isSuccessful()) {
                                Log.w(TAG, "Geofence registration failed", task.getException());
                            }
                            if (isAdded() && getContext() != null) {
                                Toast.makeText(requireContext(), R.string.location_saved, Toast.LENGTH_SHORT).show();
                            }
                        }));
            });
        });
        dialog.show();
    }

    private boolean hasLocationPermission() {
        return ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void refreshMarkers(@Nullable List<SavedLocation> locations) {
        if (googleMap == null) {
            return;
        }
        for (Marker m : markers) {
            m.remove();
        }
        markers.clear();
        for (Circle c : geofenceCircles) {
            c.remove();
        }
        geofenceCircles.clear();
        if (locations == null) {
            return;
        }
        int strokeColor = ContextCompat.getColor(requireContext(), R.color.purple_500);
        int fillColor = ContextCompat.getColor(requireContext(), R.color.geofence_fill);
        for (SavedLocation loc : locations) {
            LatLng pos = new LatLng(loc.getLatitude(), loc.getLongitude());
            Marker m = googleMap.addMarker(new MarkerOptions().position(pos).title(loc.getName()));
            if (m != null) {
                m.setTag(loc);
                markers.add(m);
            }
            Circle circle = googleMap.addCircle(new CircleOptions()
                    .center(pos)
                    .radius(loc.getRadius())
                    .strokeWidth(2f)
                    .strokeColor(strokeColor)
                    .fillColor(fillColor));
            geofenceCircles.add(circle);
        }
    }

    private void removePreviewCircle() {
        if (previewGeofenceCircle != null) {
            previewGeofenceCircle.remove();
            previewGeofenceCircle = null;
        }
    }

    private void updatePreviewGeofenceCircle(@NonNull LatLng center, float radiusMeters) {
        if (googleMap == null) {
            return;
        }
        removePreviewCircle();
        previewGeofenceCircle = googleMap.addCircle(new CircleOptions()
                .center(center)
                .radius(radiusMeters)
                .strokeWidth(2f)
                .strokeColor(ContextCompat.getColor(requireContext(), R.color.purple_500))
                .fillColor(ContextCompat.getColor(requireContext(), R.color.geofence_fill)));
    }

    private void centerOnUser() {
        if (googleMap == null) {
            return;
        }
        Location loc = viewModel.getCurrentLocation().getValue();
        if (loc == null) {
            Toast.makeText(requireContext(), R.string.no_current_location, Toast.LENGTH_SHORT).show();
            return;
        }
        LatLng ll = new LatLng(loc.getLatitude(), loc.getLongitude());
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(ll, 15f));
    }

    /**
     * Draws a driving route from the current fused location to the destination.
     *
     * @param destination saved point
     */
    public void drawDirectionsRouteTo(@NonNull SavedLocation destination) {
        if (googleMap == null) {
            return;
        }

        Location originLoc = viewModel.getCurrentLocation().getValue();
        LatLng origin;
        if (originLoc != null) {
            origin = new LatLng(originLoc.getLatitude(), originLoc.getLongitude());
        } else {
            // GPS fix may not be ready yet. Fall back to the current map center so
            // the user still gets directions immediately.
            origin = googleMap.getCameraPosition().target;
        }
        LatLng dest = new LatLng(destination.getLatitude(), destination.getLongitude());
        drawDirectionsRoute(origin, dest);
    }

    /**
     * Fetches and draws the blue route between two points.
     *
     * @param origin      start
     * @param destination end
     */
    public void drawDirectionsRoute(@NonNull LatLng origin, @NonNull LatLng destination) {
        String key = resolveMapsApiKey();
        if (key.isEmpty() || "YOUR_API_KEY_HERE".equals(key)) {
            Toast.makeText(requireContext(), R.string.directions_failed, Toast.LENGTH_SHORT).show();
            return;
        }
        String o = origin.latitude + "," + origin.longitude;
        String d = destination.latitude + "," + destination.longitude;
        DirectionsClient.get().getDirections(o, d, "driving", key).enqueue(new Callback<DirectionsResponse>() {
            @Override
            public void onResponse(@NonNull Call<DirectionsResponse> call,
                                   @NonNull Response<DirectionsResponse> response) {
                if (!isAdded() || getContext() == null) {
                    return;
                }
                if (!response.isSuccessful() || response.body() == null) {
                    Toast.makeText(getContext(), R.string.directions_failed, Toast.LENGTH_SHORT).show();
                    return;
                }
                DirectionsResponse body = response.body();
                if (body.routes == null || body.routes.isEmpty()) {
                    Toast.makeText(getContext(), R.string.directions_failed, Toast.LENGTH_SHORT).show();
                    return;
                }
                RouteJson route = body.routes.get(0);
                if (route.overview_polyline == null || route.overview_polyline.points == null) {
                    Toast.makeText(getContext(), R.string.directions_failed, Toast.LENGTH_SHORT).show();
                    return;
                }
                List<LatLng> decoded = PolyUtil.decode(route.overview_polyline.points);
                if (googleMap == null) {
                    return;
                }
                if (decoded.isEmpty()) {
                    Toast.makeText(getContext(), R.string.directions_failed, Toast.LENGTH_SHORT).show();
                    return;
                }
                if (routePolyline != null) {
                    routePolyline.remove();
                }
                routePolyline = googleMap.addPolyline(new PolylineOptions()
                        .addAll(decoded)
                        .width(12f)
                        .color(ContextCompat.getColor(requireContext(), R.color.purple_500)));
                LatLngBounds.Builder bounds = new LatLngBounds.Builder();
                for (LatLng p : decoded) {
                    bounds.include(p);
                }
                googleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds.build(), 120));
            }

            @Override
            public void onFailure(@NonNull Call<DirectionsResponse> call, @NonNull Throwable t) {
                if (!isAdded() || getContext() == null) {
                    return;
                }
                Toast.makeText(getContext(), R.string.directions_failed, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @NonNull
    private String resolveMapsApiKey() {
        String candidate = BuildConfig.MAPS_API_KEY;
        if (candidate != null) {
            candidate = candidate.trim();
        }

        // Treat empty or placeholder keys as "missing" so we can fall back to manifest meta-data.
        boolean missing = candidate == null
                || candidate.isEmpty()
                || "YOUR_API_KEY_HERE".equals(candidate);
        if (!missing) {
            return candidate;
        }

        // Fall back to AndroidManifest <meta-data> values.
        try {
            ApplicationInfo appInfo = requireContext().getPackageManager().getApplicationInfo(
                    requireContext().getPackageName(),
                    PackageManager.GET_META_DATA
            );
            Bundle meta = appInfo.metaData;
            if (meta != null) {
                String manifestKey = meta.getString("google_maps_api_key");
                if (manifestKey != null) {
                    manifestKey = manifestKey.trim();
                }
                if (manifestKey != null && !manifestKey.isEmpty() && !"YOUR_API_KEY_HERE".equals(manifestKey)) {
                    return manifestKey;
                }

                manifestKey = meta.getString("com.google.android.geo.API_KEY");
                if (manifestKey != null) {
                    manifestKey = manifestKey.trim();
                }
                if (manifestKey != null && !manifestKey.isEmpty() && !"YOUR_API_KEY_HERE".equals(manifestKey)) {
                    return manifestKey;
                }
            }
        } catch (PackageManager.NameNotFoundException ignored) {
            // Fall through to string resource fallback below.
        }

        // Last-resort fallback (may still be a placeholder in dev builds).
        return requireContext().getString(R.string.google_maps_api_key);
    }
}
