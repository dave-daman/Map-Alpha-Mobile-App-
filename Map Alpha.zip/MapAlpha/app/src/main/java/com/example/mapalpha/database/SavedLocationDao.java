package com.example.mapalpha.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

/**
 * Data access object for {@link SavedLocation} rows.
 */
@Dao
public interface SavedLocationDao {

    /**
     * Inserts a location and returns the generated row id.
     *
     * @param location entity with {@code id = 0} for auto-generate
     * @return SQLite row id
     */
    @Insert
    long insertLocation(SavedLocation location);

    /**
     * Deletes a location row.
     *
     * @param location entity to remove
     */
    @Delete
    void deleteLocation(SavedLocation location);

    /**
     * All saved locations, observed as LiveData.
     *
     * @return live list
     */
    @Query("SELECT * FROM saved_location ORDER BY createdAt DESC")
    LiveData<List<SavedLocation>> getAllLocations();

    /**
     * Loads a single location by id on the calling thread (use from background executor).
     *
     * @param id primary key
     * @return entity or null
     */
    @Query("SELECT * FROM saved_location WHERE id = :id LIMIT 1")
    SavedLocation getLocationById(int id);

    /**
     * Loads all locations on the calling thread (use from background executor).
     *
     * @return all rows
     */
    @Query("SELECT * FROM saved_location")
    List<SavedLocation> getAllLocationsSync();
}
