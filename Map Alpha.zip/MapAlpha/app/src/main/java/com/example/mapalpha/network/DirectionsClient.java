package com.example.mapalpha.network;

import com.example.mapalpha.constants.AppConstants;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Lazy Retrofit holder for the Directions API.
 */
public final class DirectionsClient {

    private static volatile DirectionsApi instance;

    private DirectionsClient() {
    }

    /**
     * @return singleton {@link DirectionsApi}
     */
    public static DirectionsApi get() {
        if (instance == null) {
            synchronized (DirectionsClient.class) {
                if (instance == null) {
                    Retrofit retrofit = new Retrofit.Builder()
                            .baseUrl(AppConstants.DIRECTIONS_BASE_URL)
                            .addConverterFactory(GsonConverterFactory.create())
                            .build();
                    instance = retrofit.create(DirectionsApi.class);
                }
            }
        }
        return instance;
    }
}
