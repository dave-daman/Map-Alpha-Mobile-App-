package com.example.mapalpha.repository;

import android.location.Location;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.mapalpha.database.AppDatabase;
import com.example.mapalpha.database.SavedLocation;
import com.example.mapalpha.database.SavedLocationDao;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Repository wrapping {@link SavedLocationDao} and exposing {@link LiveData} plus async writes.
 * Also holds the current fused {@link Location} for the foreground tracking service.
 */
public class LocationRepository {

    private final SavedLocationDao dao;
    private final ExecutorService executor;
    private final Handler mainHandler;
    private final MutableLiveData<Location> currentLocation;

    /**
     * Creates a repository backed by the app database.
     *
     * @param database singleton {@link AppDatabase}
     */
    public LocationRepository(@NonNull AppDatabase database) {
        this.dao = database.savedLocationDao();
        this.executor = Executors.newSingleThreadExecutor();
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.currentLocation = new MutableLiveData<>();
    }

    /**
     * @return live list of all saved locations
     */
    @NonNull
    public LiveData<List<SavedLocation>> getAllLocations() {
        return dao.getAllLocations();
    }

    /**
     * @return live current fused location (updated by {@link com.example.mapalpha.location.LocationTrackingService})
     */
    @NonNull
    public LiveData<Location> getCurrentLocation() {
        return currentLocation;
    }

    /**
     * Posts a new current location from the fused provider (main thread).
     *
     * @param location latest fix, or null to clear
     */
    public void postCurrentLocation(@Nullable Location location) {
        currentLocation.setValue(location);
    }

    /**
     * Inserts a location on a background thread and delivers the row with generated id on the main thread.
     *
     * @param location   entity with {@code id = 0}
     * @param callback invoked on main thread with inserted row
     */
    public void insertLocation(@NonNull SavedLocation location, @NonNull InsertCallback callback) {
        executor.execute(() -> {
            long rowId = dao.insertLocation(location);
            SavedLocation inserted = dao.getLocationById((int) rowId);
            mainHandler.post(() -> {
                if (inserted != null) {
                    callback.onInserted(inserted);
                }
            });
        });
    }

    /**
     * Deletes a location on a background thread.
     *
     * @param location entity to delete
     */
    public void deleteLocation(@NonNull SavedLocation location) {
        executor.execute(() -> dao.deleteLocation(location));
    }

    /**
     * Runs work on the repository executor (e.g. geofence sync).
     *
     * @param runnable background task
     */
    public void execute(@NonNull Runnable runnable) {
        executor.execute(runnable);
    }

    /**
     * Loads all locations synchronously on the calling thread (must be background).
     *
     * @return all rows
     */
    @NonNull
    public List<SavedLocation> getAllLocationsSync() {
        return dao.getAllLocationsSync();
    }

    /**
     * Callback after insert completes on the main thread.
     */
    public interface InsertCallback {
        /**
         * Called with the persisted row including generated primary key.
         *
         * @param inserted row including generated id
         */
        void onInserted(@NonNull SavedLocation inserted);
    }
}
