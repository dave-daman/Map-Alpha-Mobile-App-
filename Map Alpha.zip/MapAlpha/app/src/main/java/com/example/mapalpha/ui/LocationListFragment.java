package com.example.mapalpha.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mapalpha.MapAlphaApplication;
import com.example.mapalpha.R;
import com.example.mapalpha.constants.AppConstants;
import com.example.mapalpha.database.SavedLocation;
import com.example.mapalpha.geofence.GeofenceManager;
import com.example.mapalpha.viewmodel.LocationViewModel;
import com.example.mapalpha.viewmodel.LocationViewModelFactory;

import java.util.Collections;
import java.util.List;

/**
 * Lists saved locations with swipe-to-delete and navigation to the map.
 */
public class LocationListFragment extends Fragment {

    private LocationViewModel viewModel;
    private LocationAdapter adapter;
    private GeofenceManager geofenceManager;
    private TextView emptyView;

    /**
     * Creates the list fragment.
     */
    public LocationListFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_location_list, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(
                requireActivity(),
                new LocationViewModelFactory(requireActivity().getApplication()))
                .get(LocationViewModel.class);
        geofenceManager = ((MapAlphaApplication) requireActivity().getApplication()).getGeofenceManager();

        RecyclerView recycler = view.findViewById(R.id.recycler_locations);
        emptyView = view.findViewById(R.id.text_empty);
        recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new LocationAdapter(location -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).openGoogleMapsDirections(location);
            }
        });
        recycler.setAdapter(adapter);

        ItemTouchHelper touchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView,
                                  @NonNull RecyclerView.ViewHolder viewHolder,
                                  @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int pos = viewHolder.getBindingAdapterPosition();
                if (pos == RecyclerView.NO_POSITION) {
                    return;
                }
                SavedLocation loc = adapter.getItemAt(pos);
                geofenceManager.removeGeofence(AppConstants.geofenceIdForLocation(loc.getId()));
                viewModel.deleteLocation(loc);
            }
        });
        touchHelper.attachToRecyclerView(recycler);

        viewModel.getSavedLocations().observe(getViewLifecycleOwner(), this::render);
    }

    private void render(@Nullable List<SavedLocation> locations) {
        List<SavedLocation> list = locations == null ? Collections.emptyList() : locations;
        adapter.submit(list);
        emptyView.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
    }
}
