package com.example.mapalpha.notifications;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.mapalpha.R;
import com.example.mapalpha.constants.AppConstants;

/**
 * Centralizes notification channels and builders for tracking and geofence alerts.
 */
public final class NotificationHelper {

    private static final String TAG = "NotificationHelper";

    private static boolean initialized;

    private NotificationHelper() {
    }

    /**
     * Creates notification channels on API 26+.
     *
     * @param context any context
     */
    public static void init(@NonNull Context context) {
        if (initialized) {
            return;
        }
        initialized = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = context.getSystemService(NotificationManager.class);
            if (nm == null) {
                return;
            }
            NotificationChannel tracking = new NotificationChannel(
                    AppConstants.CHANNEL_TRACKING,
                    AppConstants.CHANNEL_TRACKING_NAME,
                    NotificationManager.IMPORTANCE_LOW);
            NotificationChannel geofence = new NotificationChannel(
                    AppConstants.CHANNEL_GEOFENCE,
                    AppConstants.CHANNEL_GEOFENCE_NAME,
                    NotificationManager.IMPORTANCE_HIGH);
            nm.createNotificationChannel(tracking);
            nm.createNotificationChannel(geofence);
        }
    }

    /**
     * Foreground notification for {@link com.example.mapalpha.location.LocationTrackingService}.
     *
     * @param context context for resources and system service
     * @return built notification
     */
    @NonNull
    public static Notification buildTrackingNotification(@NonNull Context context) {
        return new NotificationCompat.Builder(context, AppConstants.CHANNEL_TRACKING)
                .setContentTitle(context.getString(R.string.tracking_notification_title))
                .setContentText(context.getString(R.string.tracking_notification_text))
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .build();
    }

    /**
     * Shows a high-priority geofence entry notification.
     *
     * @param context      context
     * @param locationName name of the fenced location
     */
    public static void sendGeofenceNotification(@NonNull Context context, @NonNull String locationName) {
        NotificationManagerCompat nm = NotificationManagerCompat.from(context);
        if (!nm.areNotificationsEnabled()) {
            Log.w(TAG, "Notifications disabled; cannot show geofence alert");
            return;
        }
        Notification notification = new NotificationCompat.Builder(context, AppConstants.CHANNEL_GEOFENCE)
                .setContentTitle(context.getString(R.string.geofence_notification_title))
                .setContentText(context.getString(R.string.geofence_notification_text, locationName))
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .build();
        nm.notify(
                AppConstants.NOTIFICATION_ID_GEOFENCE_BASE + (int) System.currentTimeMillis() % 10000,
                notification);
    }
}
