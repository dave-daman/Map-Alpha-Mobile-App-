package com.example.mapalpha.geofence;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.annotation.NonNull;

import com.example.mapalpha.MapAlphaApplication;
import com.example.mapalpha.database.AppDatabase;
import com.example.mapalpha.database.SavedLocation;
import com.example.mapalpha.notifications.NotificationHelper;
import android.os.Handler;
import android.os.Looper;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofenceStatusCodes;
import com.google.android.gms.location.GeofencingEvent;

import java.util.List;

/**
 * Receives geofence transition events and raises user-visible notifications.
 */
public class GeofenceBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(@NonNull Context context, @NonNull Intent intent) {
        GeofencingEvent event = GeofencingEvent.fromIntent(intent);
        if (event == null) {
            android.util.Log.w("GeofenceReceiver", "GeofencingEvent was null");
            return;
        }
        if (event.hasError()) {
            int errorCode = event.getErrorCode();
            android.util.Log.e(
                    "GeofenceReceiver",
                    "Geofence error: " + GeofenceStatusCodes.getStatusCodeString(errorCode));
            return;
        }
        int transition = event.getGeofenceTransition();
        if (transition != Geofence.GEOFENCE_TRANSITION_ENTER) {
            return;
        }
        final PendingResult pendingResult = goAsync();
        MapAlphaApplication app = (MapAlphaApplication) context.getApplicationContext();
        AppDatabase db = AppDatabase.getInstance(app);
        List<Geofence> triggering = event.getTriggeringGeofences();
        if (triggering == null || triggering.isEmpty()) {
            pendingResult.finish();
            return;
        }
        Context appCtx = context.getApplicationContext();
        Handler main = new Handler(Looper.getMainLooper());
        app.getLocationRepository().execute(() -> {
            try {
                for (Geofence geofence : triggering) {
                    String idStr = geofence.getRequestId();
                    try {
                        int id = Integer.parseInt(idStr);
                        SavedLocation loc = db.savedLocationDao().getLocationById(id);
                        if (loc != null) {
                            String name = loc.getName();
                            main.post(() -> NotificationHelper.sendGeofenceNotification(appCtx, name));
                        }
                    } catch (NumberFormatException e) {
                        android.util.Log.w("GeofenceReceiver", "Bad geofence id: " + idStr);
                    }
                }
            } finally {
                pendingResult.finish();
            }
        });
    }
}
