package com.example.mapalpha.geofence;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.mapalpha.constants.AppConstants;
import com.example.mapalpha.database.SavedLocation;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingClient;
import com.google.android.gms.location.GeofencingRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.Task;

import java.util.List;

/**
 * Registers and removes geofences using {@link GeofencingClient}.
 */
public class GeofenceManager {

    private final Context appContext;
    private final GeofencingClient client;

    /**
     * @param context any context; application context is retained
     */
    public GeofenceManager(@NonNull Context context) {
        this.appContext = context.getApplicationContext();
        this.client = LocationServices.getGeofencingClient(appContext);
    }

    /**
     * Builds a pending intent for geofence transitions.
     *
     * @return immutable broadcast intent
     */
    @NonNull
    public PendingIntent geofencePendingIntent() {
        Intent intent = new Intent(appContext, GeofenceBroadcastReceiver.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getBroadcast(
                appContext,
                AppConstants.GEOFENCE_PENDING_INTENT_REQUEST_CODE,
                intent,
                flags);
    }

    @NonNull
    private static Geofence buildGeofence(@NonNull SavedLocation savedLocation) {
        String id = AppConstants.geofenceIdForLocation(savedLocation.getId());
        // ENTER only: alerts as soon as the device enters the region (no dwell delay).
        return new Geofence.Builder()
                .setRequestId(id)
                .setCircularRegion(
                        savedLocation.getLatitude(),
                        savedLocation.getLongitude(),
                        savedLocation.getRadius())
                .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER)
                .setExpirationDuration(Geofence.NEVER_EXPIRE)
                .setNotificationResponsiveness(0)
                .build();
    }

    /**
     * Adds a single geofence for the saved location.
     *
     * @param savedLocation row with valid id and radius
     * @return task for completion
     */
    @NonNull
    public Task<Void> addGeofence(@NonNull SavedLocation savedLocation) {
        GeofencingRequest request = new GeofencingRequest.Builder()
                .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
                .addGeofence(buildGeofence(savedLocation))
                .build();
        return client.addGeofences(request, geofencePendingIntent());
    }

    /**
     * Removes a geofence by request id.
     *
     * @param geofenceId same id used when adding
     * @return task
     */
    @NonNull
    public Task<Void> removeGeofence(@NonNull String geofenceId) {
        return client.removeGeofences(java.util.Collections.singletonList(geofenceId));
    }

    /**
     * Removes all geofences registered for this app.
     *
     * @return task
     */
    @NonNull
    public Task<Void> removeAllGeofences() {
        return client.removeGeofences(geofencePendingIntent());
    }

    /**
     * Replaces all geofences with the given list.
     *
     * @param locations list of saved locations
     * @param onComplete optional main-thread callback
     */
    public void syncGeofences(@NonNull List<SavedLocation> locations, @Nullable Runnable onComplete) {
        removeAllGeofences().addOnCompleteListener(t -> {
            if (locations.isEmpty()) {
                if (onComplete != null) {
                    onComplete.run();
                }
                return;
            }
            GeofencingRequest.Builder builder = new GeofencingRequest.Builder()
                    .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER);
            for (SavedLocation loc : locations) {
                builder.addGeofence(buildGeofence(loc));
            }
            client.addGeofences(builder.build(), geofencePendingIntent())
                    .addOnCompleteListener(t2 -> {
                        if (onComplete != null) {
                            onComplete.run();
                        }
                    });
        });
    }
}
