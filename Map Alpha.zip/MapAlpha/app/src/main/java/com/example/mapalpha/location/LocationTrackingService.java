package com.example.mapalpha.location;

import android.Manifest;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import com.example.mapalpha.MapAlphaApplication;
import com.example.mapalpha.constants.AppConstants;
import com.example.mapalpha.notifications.NotificationHelper;
import com.example.mapalpha.repository.LocationRepository;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

/**
 * Foreground service that streams high-accuracy fused location updates to {@link LocationRepository}.
 */
public class LocationTrackingService extends Service {

    private FusedLocationProviderClient fusedClient;
    private LocationCallback locationCallback;
    private LocationRepository repository;

    @Override
    public void onCreate() {
        super.onCreate();
        MapAlphaApplication app = (MapAlphaApplication) getApplication();
        repository = app.getLocationRepository();
        fusedClient = LocationServices.getFusedLocationProviderClient(this);
    }

    @Override
    public int onStartCommand(@Nullable Intent intent, int flags, int startId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                    AppConstants.NOTIFICATION_ID_TRACKING,
                    NotificationHelper.buildTrackingNotification(this),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(
                    AppConstants.NOTIFICATION_ID_TRACKING,
                    NotificationHelper.buildTrackingNotification(this));
        }
        startLocationUpdatesIfPermitted();
        return START_STICKY;
    }

    private void startLocationUpdatesIfPermitted() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            stopSelf();
            return;
        }
        LocationRequest request = new LocationRequest.Builder(AppConstants.LOCATION_UPDATE_INTERVAL)
                .setMinUpdateIntervalMillis(AppConstants.LOCATION_FASTEST_INTERVAL)
                .setPriority(Priority.PRIORITY_HIGH_ACCURACY)
                .build();
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult result) {
                Location loc = result.getLastLocation();
                if (loc != null) {
                    repository.postCurrentLocation(loc);
                }
            }
        };
        fusedClient.requestLocationUpdates(request, locationCallback, getMainLooper());
    }

    @Override
    public void onDestroy() {
        if (locationCallback != null) {
            fusedClient.removeLocationUpdates(locationCallback);
            locationCallback = null;
        }
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(@Nullable Intent intent) {
        return null;
    }
}
