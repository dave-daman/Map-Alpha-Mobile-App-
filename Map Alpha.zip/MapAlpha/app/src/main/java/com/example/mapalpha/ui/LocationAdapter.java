package com.example.mapalpha.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mapalpha.R;
import com.example.mapalpha.database.SavedLocation;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * RecyclerView adapter for saved locations with a navigate action per row.
 */
public class LocationAdapter extends RecyclerView.Adapter<LocationAdapter.LocationViewHolder> {

    /**
     * Callback when the user taps Navigate on a row.
     */
    public interface OnLocationClickListener {
        /**
         * @param location selected row
         */
        void onNavigate(@NonNull SavedLocation location);
    }

    private final OnLocationClickListener listener;
    private final List<SavedLocation> items = new ArrayList<>();

    /**
     * @param listener navigate callback
     */
    public LocationAdapter(@NonNull OnLocationClickListener listener) {
        this.listener = listener;
    }

    /**
     * Replaces the displayed list.
     *
     * @param locations new data
     */
    public void submit(@NonNull List<SavedLocation> locations) {
        items.clear();
        items.addAll(locations);
        notifyDataSetChanged();
    }

    /**
     * @param position adapter position
     * @return item at position
     */
    @NonNull
    public SavedLocation getItemAt(int position) {
        return items.get(position);
    }

    @NonNull
    @Override
    public LocationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_location, parent, false);
        return new LocationViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull LocationViewHolder holder, int position) {
        SavedLocation loc = items.get(position);
        holder.bind(loc, listener);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    /**
     * View holder for one saved location card.
     */
    static class LocationViewHolder extends RecyclerView.ViewHolder {

        private final TextView name;
        private final TextView coords;
        private final TextView radius;
        private final MaterialButton navigate;

        /**
         * @param itemView root card view
         */
        LocationViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.text_name);
            coords = itemView.findViewById(R.id.text_coords);
            radius = itemView.findViewById(R.id.text_radius);
            navigate = itemView.findViewById(R.id.button_navigate);
        }

        void bind(@NonNull SavedLocation loc, @NonNull OnLocationClickListener listener) {
            name.setText(loc.getName());
            coords.setText(String.format(Locale.US, "%.6f, %.6f", loc.getLatitude(), loc.getLongitude()));
            radius.setText(itemView.getContext().getString(R.string.radius_label, loc.getRadius()));
            navigate.setOnClickListener(v -> listener.onNavigate(loc));
        }
    }
}
