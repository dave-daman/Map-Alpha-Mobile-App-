package com.example.mapalpha.network;

import com.google.gson.annotations.SerializedName;

/**
 * Encoded polyline points string from the Directions API.
 */
public class OverviewPolyline {

    /** Encoded path. */
    @SerializedName("points")
    public String points;
}
