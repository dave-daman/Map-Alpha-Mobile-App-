package com.example.mapalpha.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.mapalpha.MapAlphaApplication;
import com.example.mapalpha.R;
import com.example.mapalpha.constants.AppConstants;
import com.example.mapalpha.database.SavedLocation;
import com.example.mapalpha.geofence.GeofenceManager;
import com.example.mapalpha.viewmodel.LocationViewModel;
import com.example.mapalpha.viewmodel.LocationViewModelFactory;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * Form to add a saved location and register its geofence.
 */
public class AddLocationFragment extends Fragment {

    private LocationViewModel viewModel;
    private GeofenceManager geofenceManager;
    private TextInputLayout inputName;
    private TextInputLayout inputLat;
    private TextInputLayout inputLng;
    private TextInputLayout inputRadius;
    private TextInputEditText editName;
    private TextInputEditText editLat;
    private TextInputEditText editLng;
    private TextInputEditText editRadius;
    private MaterialButton buttonSave;
    private MaterialButton buttonUseCurrent;

    /**
     * Creates the add-location fragment.
     */
    public AddLocationFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_add_location, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(
                requireActivity(),
                new LocationViewModelFactory(requireActivity().getApplication()))
                .get(LocationViewModel.class);
        geofenceManager = ((MapAlphaApplication) requireActivity().getApplication()).getGeofenceManager();

        inputName = view.findViewById(R.id.input_name);
        inputLat = view.findViewById(R.id.input_lat);
        inputLng = view.findViewById(R.id.input_lng);
        inputRadius = view.findViewById(R.id.input_radius);
        editName = view.findViewById(R.id.edit_name);
        editLat = view.findViewById(R.id.edit_lat);
        editLng = view.findViewById(R.id.edit_lng);
        editRadius = view.findViewById(R.id.edit_radius);
        buttonSave = view.findViewById(R.id.button_save);
        buttonUseCurrent = view.findViewById(R.id.button_use_current);

        editRadius.setText(String.valueOf((int) AppConstants.GEOFENCE_RADIUS_DEFAULT));

        buttonUseCurrent.setOnClickListener(v -> {
            android.location.Location loc = viewModel.getCurrentLocation().getValue();
            if (loc == null) {
                Toast.makeText(requireContext(), R.string.no_current_location, Toast.LENGTH_SHORT).show();
                return;
            }
            editLat.setText(String.valueOf(loc.getLatitude()));
            editLng.setText(String.valueOf(loc.getLongitude()));
        });

        buttonSave.setOnClickListener(v -> attemptSave());

        viewModel.getInsertInProgress().observe(getViewLifecycleOwner(), saving -> {
            boolean inProgress = Boolean.TRUE.equals(saving);
            buttonSave.setEnabled(!inProgress);
            buttonUseCurrent.setEnabled(!inProgress);
        });
    }

    private void attemptSave() {
        clearErrors();
        String name = text(editName);
        String latStr = text(editLat);
        String lngStr = text(editLng);
        String radStr = text(editRadius);

        if (TextUtils.isEmpty(name)) {
            inputName.setError(getString(R.string.invalid_input));
            return;
        }
        double lat;
        double lng;
        float radius;
        try {
            lat = Double.parseDouble(latStr);
            lng = Double.parseDouble(lngStr);
        } catch (NumberFormatException e) {
            Toast.makeText(requireContext(), R.string.invalid_input, Toast.LENGTH_SHORT).show();
            return;
        }
        if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
            Toast.makeText(requireContext(), R.string.invalid_input, Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(radStr)) {
            radius = AppConstants.GEOFENCE_RADIUS_DEFAULT;
        } else {
            try {
                radius = Float.parseFloat(radStr);
            } catch (NumberFormatException e) {
                inputRadius.setError(getString(R.string.invalid_input));
                return;
            }
        }
        if (radius <= 0) {
            inputRadius.setError(getString(R.string.invalid_input));
            return;
        }

        SavedLocation entity = new SavedLocation(
                0,
                name.trim(),
                lat,
                lng,
                radius,
                System.currentTimeMillis());

        viewModel.insertLocation(entity, inserted ->
                geofenceManager.addGeofence(inserted).addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        android.util.Log.w("AddLocation", "Geofence registration failed", task.getException());
                    }
                    if (getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).selectLocationsTab();
                    }
                }));
    }

    private void clearErrors() {
        inputName.setError(null);
        inputLat.setError(null);
        inputLng.setError(null);
        inputRadius.setError(null);
    }

    @NonNull
    private static String text(@Nullable TextInputEditText e) {
        if (e == null || e.getText() == null) {
            return "";
        }
        return e.getText().toString().trim();
    }
}
