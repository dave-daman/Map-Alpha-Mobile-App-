package com.example.mapalpha.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Room entity representing a user-saved map location with an optional geofence radius.
 */
@Entity(tableName = "saved_location")
public class SavedLocation {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String name;
    private double latitude;
    private double longitude;
    private float radius;
    private long createdAt;

    /**
     * Creates a new saved location. Use {@code id = 0} for auto-generate on insert.
     *
     * @param id         primary key or 0 for new row
     * @param name       display name
     * @param latitude   latitude in degrees
     * @param longitude  longitude in degrees
     * @param radius     geofence radius in meters
     * @param createdAt  creation time in epoch millis
     */
    public SavedLocation(int id, String name, double latitude, double longitude, float radius, long createdAt) {
        this.id = id;
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
        this.radius = radius;
        this.createdAt = createdAt;
    }

    /** @return row id */
    public int getId() {
        return id;
    }

    /** @param id primary key */
    public void setId(int id) {
        this.id = id;
    }

    /** @return location display name */
    public String getName() {
        return name;
    }

    /** @param name display name */
    public void setName(String name) {
        this.name = name;
    }

    /** @return latitude in degrees */
    public double getLatitude() {
        return latitude;
    }

    /** @param latitude latitude in degrees */
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    /** @return longitude in degrees */
    public double getLongitude() {
        return longitude;
    }

    /** @param longitude longitude in degrees */
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    /** @return geofence radius in meters */
    public float getRadius() {
        return radius;
    }

    /** @param radius geofence radius in meters */
    public void setRadius(float radius) {
        this.radius = radius;
    }

    /** @return creation timestamp (epoch millis) */
    public long getCreatedAt() {
        return createdAt;
    }

    /** @param createdAt creation timestamp */
    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }
}
