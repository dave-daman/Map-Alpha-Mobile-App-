package com.example.mapalpha.geofence;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.annotation.NonNull;

import com.example.mapalpha.MapAlphaApplication;
import com.example.mapalpha.database.SavedLocation;

import java.util.List;

/**
 * Re-registers geofences after device boot using the current database snapshot.
 */
public class GeofenceBootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(@NonNull Context context, @NonNull Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            return;
        }
        MapAlphaApplication app = (MapAlphaApplication) context.getApplicationContext();
        app.getLocationRepository().execute(() -> {
            List<SavedLocation> all = app.getLocationRepository().getAllLocationsSync();
            app.getGeofenceManager().syncGeofences(all, null);
        });
    }
}
