package com.example.mapalpha.network;

import com.google.gson.annotations.SerializedName;

/**
 * One route in a Directions response.
 */
public class RouteJson {

    /** Encoded overview polyline for the full route. */
    @SerializedName("overview_polyline")
    public OverviewPolyline overview_polyline;
}
