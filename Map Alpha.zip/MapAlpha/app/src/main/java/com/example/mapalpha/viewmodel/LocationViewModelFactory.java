package com.example.mapalpha.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

/**
 * Factory that supplies {@link LocationViewModel} with the application-scoped repository.
 */
public class LocationViewModelFactory implements ViewModelProvider.Factory {

    private final Application application;

    /**
     * @param application host {@link Application}
     */
    public LocationViewModelFactory(@NonNull Application application) {
        this.application = application;
    }

    @NonNull
    @Override
    @SuppressWarnings("unchecked")
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        if (LocationViewModel.class.isAssignableFrom(modelClass)) {
            return (T) new LocationViewModel(application);
        }
        throw new IllegalArgumentException("Unknown ViewModel: " + modelClass);
    }
}
