package com.example.mapalpha.network;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Top-level JSON model for Google Directions API responses.
 */
public class DirectionsResponse {

    /** Parsed routes; may be empty when no route exists. */
    @SerializedName("routes")
    public List<RouteJson> routes;
}
